# Prueba tecnica BA / DA

## Contexto

Eres analista para una empresa de e-commerce. La direccion comercial quiere entender el desempeno del primer semestre de 2026, detectar oportunidades o riesgos y decidir donde actuar durante el siguiente mes.

Se entregan cuatro tablas en CSV y una base SQLite con la misma informacion:

- `customers`: cliente, fecha de registro, region y canal de adquisicion.
- `orders`: orden, fecha, cliente, canal de compra y estatus.
- `order_items`: productos, cantidades, precios y descuentos por orden.
- `products`: producto y categoria.

Considera como ingreso neto por articulo:

`quantity * unit_price * (1 - discount_pct)`

Para metricas comerciales, incluye solamente ordenes con estatus `Completada`, salvo que indiques lo contrario.

## Entregables

Entrega un archivo comprimido o repositorio con:

1. `analisis.sql`: consultas SQL comentadas.
2. Un notebook `.ipynb` o script `.py` reproducible.
3. `resumen_ejecutivo.md` o una presentacion de maximo 3 slides.

Puedes usar SQLite, PostgreSQL, BigQuery u otro dialecto, siempre que indiques cual utilizaste. Se evaluara el razonamiento y la claridad, no el formato visual sofisticado.

## Parte 1: SQL - 40 puntos - 55 minutos sugeridos

1. **Desempeno mensual.** Genera una tabla por mes con ingreso neto, ordenes completadas, clientes unicos y ticket promedio.
2. **Categoria lider.** Para cada mes, identifica la categoria con mayor ingreso neto. Incluye el ingreso de la categoria y su porcentaje del ingreso total del mes.
3. **Clientes recurrentes.** Calcula, por region, el porcentaje de clientes compradores que realizaron al menos dos ordenes completadas durante el periodo.
4. **Riesgo operativo.** Calcula la tasa de cancelacion por mes y canal. Devuelve solamente las combinaciones cuya tasa sea mayor a 15%, junto con el total de ordenes usado como denominador.

Incluye una nota breve sobre cualquier decision o supuesto relevante.

## Parte 2: Python - 35 puntos - 60 minutos sugeridos

Usando Python y los CSV:

1. Realiza una revision basica de calidad de datos. Reporta al menos tres controles relevantes y sus resultados.
2. Construye una tabla semanal con ingreso neto, ordenes completadas y ticket promedio.
3. Identifica las semanas en las que el ingreso neto disminuyo mas de 15% respecto a la semana anterior. Incluye una visualizacion sencilla de la tendencia semanal.
4. Crea una segmentacion util de clientes usando comportamiento de compra. Define la logica, presenta el tamano y valor de cada segmento, y explica un posible uso de negocio.

El codigo debe poder ejecutarse de principio a fin. Puedes usar `pandas`, `matplotlib`, `seaborn` o librerias equivalentes.

## Parte 3: Analisis de negocio - 25 puntos - 35 minutos sugeridos

Prepara un resumen para una persona directora no tecnica que incluya:

- Tres hallazgos relevantes, respaldados por datos.
- Dos acciones recomendadas, indicando impacto esperado y como medirias el resultado.
- Una limitacion del analisis o dato adicional que pedirias antes de tomar una decision importante.
- Una definicion clara del KPI principal que recomendarias monitorear semanalmente.

Se valora distinguir entre hechos observados, hipotesis y recomendaciones.

## Tiempo y reglas

- Tiempo objetivo: **2 horas 30 minutos**.
- Tiempo maximo recomendado: **3 horas**.
- Documenta cualquier ayuda externa o herramienta de IA utilizada.
- No es necesario construir modelos predictivos ni dashboards.
- Si no terminas una seccion, explica brevemente como la completarias.

## Criterios generales

Se evaluara exactitud, reproducibilidad, claridad, criterio de negocio, manejo de supuestos y capacidad para comunicar prioridades.
